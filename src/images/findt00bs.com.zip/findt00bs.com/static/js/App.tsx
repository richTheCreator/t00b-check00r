import React, { useEffect, useState } from "react";
import { gql } from "@apollo/client";
import "./App.css";
import { getToobForDeadGodNumber } from "./getToobForDeadGodNumber";
import {
  ThemeProvider,
  createTheme,
  TextField,
  Typography,
} from "@mui/material";
import LoadingButton from "@mui/lab/LoadingButton";
import { Nft } from "./types";
import client from "./client";
import { PublicKey } from "@solana/web3.js";
import { Buffer } from "buffer";
import { Box } from "@mui/system";
import { IconButton } from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faGithub, faTwitter } from "@fortawesome/free-brands-svg-icons";
import { faHeart } from "@fortawesome/free-solid-svg-icons";
import ReactGA from "react-ga";

const TRACKING_ID = "UA-69544920-1";
ReactGA.initialize(TRACKING_ID);

const GET_NFT_OWNER = gql`
  query GetNft($address: String!) {
    nft(address: $address) {
      address
      owner {
        address
      }
    }
  }
`;

interface GetNftData {
  nft: Nft;
}

const font = "'Literata', serif";
const theme = createTheme({
  typography: {
    fontFamily: font,
  },
});

const getWindowSize = () => {
  const { innerWidth, innerHeight } = window;
  return { innerWidth, innerHeight };
};

const App = () => {
  const [didTheyMint, setDidTheyMint] = React.useState<boolean | undefined>(
    undefined
  );
  const [numberToCheck, setNumberToCheck] = React.useState<string | undefined>(
    undefined
  );
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  const [windowSize, setWindowSize] = useState(getWindowSize());

  useEffect(() => {
    function handleWindowResize() {
      setWindowSize(getWindowSize());
    }

    window.addEventListener("resize", handleWindowResize);

    return () => {
      window.removeEventListener("resize", handleWindowResize);
    };
  }, []);

  const getOwnerOfToob = async (mintAddress: string) => {
    const PROGRAM_ID = new PublicKey(
      "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
    );
    const mintAddressKey = new PublicKey(mintAddress);
    const metadataBuffer = Buffer.from("metadata");
    const programIdBuffer = PROGRAM_ID.toBuffer();
    const mintAddressBuffer = mintAddressKey.toBuffer();

    const pda = await PublicKey.findProgramAddress(
      [metadataBuffer, programIdBuffer, mintAddressBuffer],
      PROGRAM_ID
    );

    const {
      data: { nft },
    } = await client.query<GetNftData>({
      fetchPolicy: "network-only",
      query: GET_NFT_OWNER,
      variables: {
        address: pda[0].toBase58(),
      },
    });

    return nft?.owner?.address;
  };

  const onClick = async () => {
    ReactGA.event({
      category: "Find t00bs",
      action: "onClick",
      label: `DeadGod number being checking: ${numberToCheck}`,
    });

    if (!isLoading && !showErrorState()) {
      setIsLoading(true);
      setDidTheyMint(undefined);
      const mintAddress = getToobForDeadGodNumber(Number(numberToCheck));
      if (mintAddress) {
        const ownerOfT00b = await getOwnerOfToob(mintAddress);
        setDidTheyMint(
          ownerOfT00b !== "yootn8Kf22CQczC732psp7qEqxwPGSDQCFZHkzoXp25"
        );
      }
      setIsLoading(false);
    }
  };

  const showErrorState = () => {
    if (!numberToCheck) return false;

    const deadGodNumber = Number(numberToCheck);
    if (isNaN(deadGodNumber)) {
      return true;
    }

    return deadGodNumber < 1 || deadGodNumber > 10000;
  };

  return (
    <ThemeProvider theme={theme}>
      <Box
        style={{
          backgroundColor: "#EFEDE4",
          height: "100vh",
          width: "100vw",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "right",
          }}
        >
          <IconButton href="http://twitter.com/0xSoz">
            <FontAwesomeIcon icon={faTwitter} />
          </IconButton>
          <IconButton href="http://github.com/roederw">
            <FontAwesomeIcon icon={faGithub} />
          </IconButton>
        </Box>

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Box
            component="img"
            sx={{
              width: "70%",
              maxWidth: "475px",
            }}
            alt="Logo"
            src={process.env.PUBLIC_URL + "/logo.png"}
          />
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              textAlign: "center",
              paddingTop: "96px",
            }}
          >
            {didTheyMint === undefined && (
              <Typography variant="h3" color={"#587491"} gutterBottom>
                {`Did they mint a t00b?`}
              </Typography>
            )}
            {didTheyMint !== undefined &&
              (didTheyMint ? (
                <Typography variant="h3" color={"#587491"} gutterBottom>
                  {`Yes! They minted a t00b!`}
                </Typography>
              ) : (
                <Typography variant="h3" color={"#FE5A31"} gutterBottom>
                  {`They did n0t!`}
                </Typography>
              ))}
            <Typography variant="h6" gutterBottom>
              {`Enter a DeadGod # (1 - 10,000)`}
            </Typography>
            <TextField
              error={showErrorState()}
              value={numberToCheck}
              onChange={(event) => {
                setNumberToCheck(event.target.value);
              }}
              onKeyPress={(ev) => {
                if (ev.key === "Enter") {
                  onClick();
                  ev.preventDefault();
                }
              }}
              variant="outlined"
            />
            <Box
              sx={{
                flexDirection: "row",
                paddingTop: "10px",
              }}
            >
              <LoadingButton
                variant="outlined"
                loading={isLoading}
                onClick={onClick}
                disabled={!numberToCheck || showErrorState()}
              >
                Find the t00b
              </LoadingButton>
            </Box>
          </Box>
        </Box>
        <Box
          sx={{
            textAlign: "center",
            position: "absolute",
            left: "0",
            bottom: "0",
            right: "0",
            paddingBottom: "10px",
          }}
        >
          {windowSize.innerHeight > 700 && (
            <Box
              component="img"
              sx={{
                height: 80,
                width: 80,
                borderRadius: "100px",
                marginBottom: "23px",
              }}
              alt="Logo"
              src={process.env.PUBLIC_URL + "/deadgod.jpg"}
            />
          )}
          <Box>
            Made with <FontAwesomeIcon color={"red"} icon={faHeart} /> by
            KingSoz
          </Box>
        </Box>
      </Box>
    </ThemeProvider>
  );
};

export default App;
